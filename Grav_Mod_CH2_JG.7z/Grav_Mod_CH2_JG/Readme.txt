README MODS

I modified the gravity to ajust the players feel as he moved thorugh the maze.
With it set now it feels as though the player was heavy on his feet.
This could potentially be used to make a drunk or tired effect. As the player gets
"tired" the gravity level could increase.